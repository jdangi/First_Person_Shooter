﻿using UnityEngine;
using System.Collections;

public class EnemyStats : MonoBehaviour {

	public string Id;
	public float Health;
}
