﻿using UnityEngine;
using System.Collections;

public class PlayerDetails : MonoBehaviour 
{
	public float playerHealth;
	public int currentLevel;
	// Use this for initialization
	void Start () 
	{
		playerHealth = 100f;
		currentLevel = 1;
	}
	
	// Update is called once per frame
	void Update () 
	{
	
	}
}
